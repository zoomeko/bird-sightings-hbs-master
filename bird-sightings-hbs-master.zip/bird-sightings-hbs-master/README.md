# bird-sightings-hbs

Node/Express/MongoDB/Mongoose app, using more complex schema design and validation
